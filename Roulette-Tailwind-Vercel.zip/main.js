function spin() {
  const outcome = Math.floor(Math.random() * 36);
  document.getElementById('roulette').innerText = `Result: ${outcome}`;
}