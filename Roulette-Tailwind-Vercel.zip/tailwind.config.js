module.exports = {
  content: ["./*.html"],
  theme: { extend: {} },
  plugins: [],
}