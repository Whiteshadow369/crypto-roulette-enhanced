# Crypto Roulette
Simple roulette game styled with Tailwind CSS.